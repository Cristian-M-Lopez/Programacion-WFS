import "./styles.css";
//EJERCICIO A

var cocinaUnaTorta = [
  "Torta de Aceite",
  "1-En un bol Colocas los huevos,el azúcar,el aceite,la leche",
  "2-Batir a mano pero no mucho",
  "3-Agregas la vainilla o lo que quieras",
  "4-Agregar Harina",
  "5-Hornear por 35/40' a 180°"
];

for (let i = 0; i < cocinaUnaTorta.length; i++) {
  let pasos = cocinaUnaTorta[i];
  console.log(pasos);
}

//EJERCICIO B

var posteoFacebook = [
  "Agregar Producto en Marketplace",
  "1-Iniciar sesion",
  "2-Ir a la seccion marketplace",
  "3-Crear Publicacion",
  "4-Elegir tipo de publicacion",
  "5-Agregar Foto",
  "6-Agregar Titulo",
  "7-Agregar Detalle",
  "8-Enviar Publicacion"
];

for (let i = 0; i < posteoFacebook.length; i++) {
  let pasosASeguir = posteoFacebook[i];
  console.log(pasosASeguir);
}
